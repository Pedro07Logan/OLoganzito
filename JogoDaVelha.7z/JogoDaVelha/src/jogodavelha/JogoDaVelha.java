package jogodavelha;
import DAO.JogadorDAO;
import VIEW.JogoDaVelhaGUI;

import javax.swing.JOptionPane;

public class JogoDaVelha {
      JogoDaVelhaGUI janela = new JogoDaVelhaGUI();
    }

